
## Running

* Running on a cluster: refer to the specific guides for @ref:[OpenShift](openshift.md) and @ref:[Kubernetes (`minikube`)](kubernetes.md)
for specific information on deploying in Kubernetes-based clusters.

* Run @ref[locally](locally.md)
